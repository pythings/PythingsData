
You need to download the firmwares here before strarting the installers:

 - esp8266-20180511-v1.9.4.bin
 - esp32-20181105-v1.9.4-683-gd94aa577a.bin

Then, Enter the "deps" folder and run the install_esp32.py or install_esp32.py from there (use "../".)

The copy_files_and_reboot.py is quite useful for quick development.


