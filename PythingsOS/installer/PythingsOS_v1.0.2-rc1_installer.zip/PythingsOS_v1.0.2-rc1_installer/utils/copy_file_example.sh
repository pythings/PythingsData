ampy -p /dev/cu.wchusbserial1420 put /Users/ste/Devel/workspaces/PythingsOS/esp8266/hal.py
