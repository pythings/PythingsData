#!/bin/bash

here="`dirname \"$0\"`"
echo "Moving to $here"
cd $here

python installer.py

