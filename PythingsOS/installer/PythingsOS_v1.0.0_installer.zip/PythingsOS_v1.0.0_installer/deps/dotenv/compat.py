try:
    from StringIO import StringIO  # noqa
except ImportError:
    from io import StringIO  # noqa
