
import os

def install(path='/'):
    try:
        os.stat(path+'initialized')
        return
    except:
        pass

    print('[INFO] Initializing',path+'/api.py')
    with open(path+'/api.py','w') as f:
        f.write('''
import env
import logger
import json
try:
    from http_extended import post
except ImportError:
    from http import post
import gc

apiver='v1'

# Utility
def check_response(response):
    if response['status'] not in [b'200', 200]:
        try:
            msg=response['content']
            if not msg: msg=response 
        except Exception:
            msg=response
        raise Exception(msg)

# Apis
def apost(api, data={}):
    url = '{}/api/{}{}'.format(env.backend,apiver,api)
    logger.debug('Calling API {} with data'.format(url),data)
    response = post(url, data=data)
    gc.collect()
    logger.info('Got response:',response)
    check_response(response)
    if response['content'] and response['content'] != '\\n':
        response['content'] = json.loads(response['content']) 
    return response

def download(file_name, version, dest, what, platform):
    logger.info('Downloading {} in'.format(file_name),dest) 
    response = post(env.backend+'/api/'+apiver+'/'+what+'/get/', {'file_name':file_name, 'version':version, 'token':env.token, 'platform':platform}, dest=dest)
    check_response(response)

# Report
def report(what, status, message=None):
    message_for_logger = message['msg'] if isinstance(message,dict) and 'msg' in message else message
    message_for_logger = message_for_logger[0:30]+'...' if message_for_logger and len(message_for_logger) >30 else message_for_logger
    logger.info('Reporting "{}" as "{}" with message "{}"'.format(what,status,message_for_logger))
    response = apost('/things/report/', {'what':what,'status': status,'msg': message})
    logger.debug('Response:',response)
''')
        f.write('''''')

    print('[INFO] Initializing',path+'/boot.py')
    with open(path+'/boot.py','w') as f:
        f.write('''import gc
import os
import sys
import json
import env
gc.collect()

# Set root path
env.root = '/'

print('')
try:
    try:
        with open(env.root+'/settings.json','r') as f:
            pythings_version = json.loads(f.read())['pythings_version'] 
    except Exception as e:
        pythings_version = 'FACTORY'

    if not pythings_version.upper() == 'FACTORY':
        path = env.root+'/'+pythings_version
        print('BOOT: Trying to load Pythings version {} from {}'.format(pythings_version,path))
        try:
            os.stat(path)
        except OSError:
            print('BOOT: Proceeding with factory default version...')
            path=env.root
        else:
            try:
                os.stat(path+'/version.py')
            except OSError:
                print('BOOT: Error, proceeding with factory default version...')
                path=env.root
            else:
                print('BOOT: OK, valid version {} found and loading...'.format(pythings_version))
                sys.path.insert(0, path)
    else:
        path=env.root

except Exception as e:
    print('BOOT: Error, proceeding with factory defaults: ',e.__class.__.__name__, str(e))
    path=env.root

# Execute Pythings framework (from right path inserted above)
try:
    import init
    gc.collect()
    init.start()
except Exception as e:
    import handle_main_error
    handle_main_error.handle(e) 
    # TODO: Fallback on factory version?
finally:
    del env

    

''')
        f.write('''''')

    print('[INFO] Initializing',path+'/common.py')
    with open(path+'/common.py','w') as f:
        f.write('''import time
import logger
import pal

def run_controlled(retr, function, **kwargs):
    count=0
    while True:
        try:
            return function(**kwargs)   
        except Exception as e:
            logger.error('Error in executing controlled step ({}): {} {}'.format(function,e.__class__.__name__,e))
            logger.debug(pal.get_traceback(e))
            if retr == None or count < retr:
                count += 1
                logger.info('Retrying (#{}) in 3 seconds...'.format(count))
                time.sleep(3)
            else:
                logger.info('Exiting due to maximum retries reached')
                return
        finally:
            import gc
            gc.collect()

def get_app_version():
    try:
        from app import version as app_version
    except Exception as e:
        logger.info('Cannot obtain App version ({}:{}), falling back on version 0'.format(e.__class__.__name__, e))
        app_version='0'
    return app_version

def get_pythings_version():
    try:
        from version import version
    except Exception as e:
        logger.error('Error in obtaining Pythings version ({}: {}), skipping...'.format(e.__class__.__name__, e))
        version='Unknown'
    return version
''')
        f.write('''''')

    print('[INFO] Initializing',path+'/env.py')
    with open(path+'/env.py','w') as f:
        f.write('''''')
        f.write('''''')

    print('[INFO] Initializing',path+'/files.txt')
    with open(path+'/files.txt','w') as f:
        f.write('''file:1638:api.py
file:1242:common.py
file:0:env.py
file:472:files.txt
file:724:handle_main_error.py
file:3957:http.py
file:3826:http_extended.py
file:6470:init.py
file:642:logger.py
file:3999:management.py
file:2976:pal.py
file:28:platform.py
file:1030:preregister.py
file:977:register.py
file:16273:SIM800L.py
file:849:updates_app.py
file:747:updates_pythings.py
file:325:updates_settings.py
file:1793:utils.py
file:6868:websetup.py
file:855:worker.py
file:17:version.py
''')
        f.write('''''')

    print('[INFO] Initializing',path+'/hal.py')
    with open(path+'/hal.py','w') as f:
        f.write('''import machine

# Hardware-dependent platform objects and routines which can
# (or might have to) be overwritten here. Note that if you
# overwrite them here, they won't be OTA-updatable anymore.
from pal import LED
from pal import WLAN
from pal import Chronos
from pal import get_tid
from pal import get_reset_cause
from pal import is_frozen
from pal import reboot

# Hardware settings
HW_SUPPORTS_DEEPSLEEP  = False
HW_SUPPORTS_RESETCAUSE = True
HW_SUPPORTS_LED        = False
HW_SUPPORTS_WLAN       = True
HW_SUPPORTS_SSL        = True if is_frozen() else False
HW_SUPPORTS_ENCRYPTION = True if is_frozen() else False
USE_ENCRYPTION_DEFAULT = False
WEBSETUP_RESETCAUSES   = [machine.PWRON_RESET, machine.HARD_RESET, machine.WDT_RESET]

# Hardware initialization (i.e. put PWMs to zero)
def init():
    pass

# Modem settings
from pal import MODEM_PWKEY_PIN, MODEM_RST_PIN, MODEM_POWER_ON_PIN, MODEM_TX_PIN, MODEM_RX_PIN
''')
        f.write('''''')

    print('[INFO] Initializing',path+'/handle_main_error.py')
    with open(path+'/handle_main_error.py','w') as f:
        f.write('''import logger

def handle(e):
    # Do not move the following import on top or code will fail (why?!)
    import pal
    logger.error('Error in executing Pythings OS: "{}". Will report and rebot.'.format(e))
    logger.debug(pal.get_traceback(e))
    try:
        from api import report
        report(what='pythings', status='KO', message='{} {} ({})'.format(e.__class__.__name__, e, pal.get_traceback(e)))
    except Exception as e2:
        logger.error('Could not report error to Pythings Cloud: "{}"'.format(e2))
        logger.debug(pal.get_traceback(e2))
    import time
    time.sleep(1)
    logger.info('I will reboot in 5 seconds. CTRL-C now to stop the reboot.')
    time.sleep(5)
    import hal
    hal.reboot()
''')
        f.write('''''')

    print('[INFO] Initializing',path+'/http.py')
    with open(path+'/http.py','w') as f:
        f.write('''from pal import socket
import json
import logger
import hal
import pal
import env
import gc

def post(url, data, dest=None):
    use_ssl = env.settings['ssl'] if 'ssl' in env.settings else True
    try: token = env.token
    except AttributeError: token=None
    if  env.payload_encrypter and token:
        data = json.dumps(data)
        # Encrypt progressively
        encrypted=''
        while data:
            encrypted +=  env.payload_encrypter.encrypt_text(data[:12])
            data = data[12:]
        data =  {'encrypted': encrypted}

    if token: data['token'] = token
    port = 443 if (hal.HW_SUPPORTS_SSL and use_ssl) else 80
    host, path = url.split('/', 1)
    if ':' in host:
        port=int(host.split(':')[1])
        host=host.split(':')[0]
    logger.debug('Calling POST "{}:{}/{}" with data'.format(host,port,path),data)
    try:
        addr = socket.getaddrinfo(host, port)[0][-1]
    except IndexError:
        raise Exception('Cannot resolve host "{}"'.format(host))
    s = socket.socket()
    try: s.settimeout(60)
    except: pass

    # If socket connect fails do not have an exception when closing file in the finally
    if dest: f = None

    # Connect and handle SSL
    s.connect(addr)
    if hal.HW_SUPPORTS_SSL and use_ssl:
        s = pal.socket_ssl(s)
   
    try:
        
        if dest: f = open(dest, 'w')
        
        pal.socket_write(s, bytes('%s /%s HTTP/1.0\\r\\nHost: %s\\r\\n' % ('POST', path, host), 'utf8'))

        content = json.dumps(data)
        content_type = 'application/json'

        if content is not None:
            pal.socket_write(s, bytes('content-length: %s\\r\\n' % len(content), 'utf8'))
            pal.socket_write(s, bytes('content-type: %s\\r\\n' % content_type, 'utf8'))
            pal.socket_write(s, bytes('\\r\\n', 'utf8'))
            pal.socket_write(s, bytes(content, 'utf8'))
        else:
            pal.socket_write(s, bytes('\\r\\n', 'utf8'))

        # Status, msg etc.
        version, status, msg = pal.socket_readline(s).split(None, 2)
    
        # Skip headers
        while pal.socket_readline(s) != b'\\r\\n':
            pass
    
        # Read data
        content   = None
        stop      = False
        while True:
            data=''

            while len(data) < 39:
                last = str(pal.socket_read(s, 1), 'utf8')
                if len(last) == 0:
                    stop=True
                    break
                else:
                    # If newline and not dest, likely it is not a JSON but an error page. Break to avoid memory problems.
                    if not dest and last == '\\n':
                        stop=True
                        break
                    data += last

            # Break now if len(data) == 0 which means that there is no more data in the socket at all.
            if len(data) == 0:
                break

            logger.debug('Received data', data)
            if dest and status == b'200':
                # load content, check ''')
        f.write('''if prev_content[-1] + content[1] == \\n,
                if env.payload_encrypter:
                    content = env.payload_encrypter.decrypt_text(data)
                    #logger.debug('Decrypted data', content)
                else:
                    content = data
                f.write(content)
            else:
                if content is None:
                    content=''

                if env.payload_encrypter:
                    content += env.payload_encrypter.decrypt_text(data)
                    #logger.debug('Decrypted data', content)
                else:
                    content +=data

            # Cleanup & stop if it was the last data chunk
            del data
            gc.collect()
            if stop:
                break

        return {'version':version, 'status':status, 'msg':msg, 'content':content}
    except:
        raise
    finally:
        if dest and f:
            f.close()
        s.close()

''')

    print('[INFO] Initializing',path+'/http_extended.py')
    with open(path+'/http_extended.py','w') as f:
        f.write('''from pal import socket
import json
import logger
import hal
import pal
import env
import gc
import network
from utils import load_param
from SIM800L import Modem
from platform import platform

class Uart(object):

    def __init__(self, softuart):
        self.softuart=softuart
    
    def write(self, string):
        self.softuart.flush()
        self.softuart.write(string)

    def readline(self):
        line=bytes()
        while True:
            char = chr(self.softuart.get())            
            if char == '\\x00':
                return line
            line += char.encode('utf8')
            if char == '\\n':
                return line

# Do we have a modem configured?
try:
    env.apn
except AttributeError:
    env.apn = load_param('apn', None)

# Should we use AT-based, modem POST?
if (not network.WLAN(network.STA_IF).isconnected()) and env.apn:
    logger.debug('Using AT post')
    use_at_post = True
else:
    logger.debug('Using socket post')
    use_at_post = False

# Define AT-based post for AT modems
def at_post(url, data, dest=None):
    
    # Do we have the Modem ready?
    try:
        env.modem
    except AttributeError:
        # Do we have to load custom pins?
        modem_pins = load_param('modem_pins', None)
        if modem_pins:
            MODEM_PWKEY_PIN, MODEM_RST_PIN, MODEM_POWER_ON_PIN, MODEM_TX_PIN, MODEM_RX_PIN = [int(pin) if pin != 'None' else None for pin in modem_pins.split(',')]

        # Create new modem object on the right Pins
        if platform.startswith('esp8266'):
        
            from machine import SOFTUART
            uart=Uart(SOFTUART(tx = MODEM_TX_PIN if modem_pins else hal.MODEM_TX_PIN,
                               rx = MODEM_RX_PIN if modem_pins else hal.MODEM_RX_PIN,
                               baudrate=9600))
            env.modem = Modem(uart)

        else:        
            env.modem = Modem(MODEM_PWKEY_PIN    = MODEM_PWKEY_PIN if modem_pins else hal.MODEM_PWKEY_PIN,
                              MODEM_RST_PIN      = MODEM_RST_PIN if modem_pins else hal.MODEM_RST_PIN,
                              MODEM_POWER_ON_PIN = MODEM_POWER_ON_PIN if modem_pins else hal.MODEM_POWER_ON_PIN,
                              MODEM_TX_PIN       = MODEM_TX_PIN if modem_pins else hal.MODEM_TX_PIN,
                              MODEM_RX_PIN       = MODEM_RX_PIN if modem_pins else hal.MODEM_RX_PIN)
        env.modem.initialize()
    
    # Always connect, as if it is already connected won't do anything
    env.modem.connect(apn=env.apn)

    #----------------------
    #  Post start
    #----------------------

    try: token = env.token
    except AttributeError: token=None    
    if token: data['token'] = token  
    logger.debug('Calling POST "{}" with data'.format(url),data)

    # If POST fails do not have an exception when closing file in the finally
    if dest: f = None

    try:
        if dest: f = open(dest, 'w')    
        
        # Execute POST
        response = env.modem.http''')
        f.write('''_request('http://'+url, 'POST', json.dumps(data), 'application/json')
        logger.debug('Received status code', response.status_code )
        logger.debug('Received content', response.content)
        status  = response.status_code   
        content = response.content

        if dest and status == 200:
            f.write(content)

        else:
            if content is None:
                content = ''

        return {'version':None, 'status':status, 'msg':None, 'content':content}
    except:
        raise
    finally:
        if dest and f:
            f.close()

# Define socket-based post
from http import post as socket_post

# Define wrapper post
def post(url, data, dest=None):
    if use_at_post:
        return at_post(url, data, dest=dest)
    else:
        return socket_post(url, data, dest=dest)


''')

    print('[INFO] Initializing',path+'/init.py')
    with open(path+'/init.py','w') as f:
        f.write('''
#  Imports
from time import sleep
import gc
import env
import common
import hal
import pal
from utils import load_param
from platform import platform

# Logger
import logger
logger.level = int(load_param('loglevel', logger.INFO))

# Start
def start():

    # Get Pythings version
    env.pythings_version = common.get_pythings_version()

    print('\\n|--------------------------|')
    print('|  Starting PythingsOS :)  |')
    print('|--------------------------|')
    print(' Version: {}'.format(env.pythings_version))
    print(' Platform: {}'.format(platform))
    try: print(' Thing ID: {}\\n'.format(hal.get_tid()))
    except: pass

    # Init hardware and platform
    hal.init()
    pal.init()
    
    # Start setup  mode if required
    if hal.HW_SUPPORTS_RESETCAUSE and hal.HW_SUPPORTS_WLAN and hal.get_reset_cause() in hal.WEBSETUP_RESETCAUSES:
        setup_timeout = int(load_param('setup_timeout', 60))
        if setup_timeout:
            if hal.HW_SUPPORTS_LED: hal.LED.on()
            from websetup import websetup
            gc.collect()
            websetup(timeout_s=setup_timeout)
            if hal.HW_SUPPORTS_LED: hal.LED.off()
            logger.info('Resetting...')
            hal.reboot()

    # Disable AP mode, Enable and configure STA mode 
    if hal.HW_SUPPORTS_WLAN:
        hal.WLAN.ap_active(False)
        hal.WLAN.sta_active(True)

    # Start loading settings and parameters
    from utils import load_settings
    env.settings = load_settings()
    env.payload_encrypter = None # Initalization

    # Load backend: the local param wins 
    env.backend = load_param('backend', None)

    if not env.backend:
        backend_overrided = False
        if 'backend' in env.settings and env.settings['backend']:
            env.backend = env.settings['backend']
        else:
            env.backend = 'backend.pythings.io'
    else:
        backend_overrided = True

    # Load aid and tid: only local param or default
    env.aid = load_param('aid', None)
    if env.aid is None:
        logger.critical('AID not provided, stopping here. Please set it up!')
        import time
        while True:
            time.sleep(1)
    env.tid = load_param('tid', None)
    if env.tid is None: env.tid = hal.get_tid()

    # Load pool: the local param wins 
    env.pool = load_param('pool', None)
    if not env.pool:
        if 'pool' in env.settings and env.settings['pool']:
            env.pool = env.settings['pool']
      
    env.frozen = hal.is_frozen()

    # Tasks placeholders
    env.app_workerTask = None
    env.app_managementTask = None
      
    # Report
    logger.info('Running with backend="{}" and aid="{}"'.format(env.backend, env.aid))

    # Get app version:
    env.app_version = common.get_app_version()

    # Register and perform the first management task call on "safe" backend, if not overrided
    if not backend_overrided:
        backend_set = env.backend
        env.backend ='backend.pythings.io'
    
    # Pre-register if paylo''')
        f.write('''ad encryption activated
    use_payload_encryption = env.settings['payload_encryption'] if 'payload_encryption' in env.settings else hal.USE_ENCRYPTION_DEFAULT
    if use_payload_encryption and hal.HW_SUPPORTS_ENCRYPTION and pal.get_payload_encrypter():
        logger.info('Enabling Payload Encryption and preregistering')
        env.payload_encrypter = pal.get_payload_encrypter()(comp_mode=True)
        from preregister import preregister
        token = preregister()
        env.token = token
        logger.info('Got token: {}'.format(env.token))
        del preregister
        gc.collect()
        
    # Register yourself, and start a new session
    from register import register
    token, epoch = register()
    if not env.payload_encrypter:
        env.token = token
        logger.info('Got token: {}'.format(env.token))
    del register
    gc.collect()
    
    # Sync time and add to env
    chronos = hal.Chronos(epoch)
    env.chronos = chronos

    # Call system management (will update App/Pythings versions  and settings if required)
    logger.info('Calling system management (preloop)')
    from management import system_management_task
    system_management_task(chronos)
    del system_management_task
    gc.collect()
    
    # Set back host to the proper one
    if not backend_overrided:
        env.backend=backend_set
        del backend_set
    gc.collect()

    # Init app
    try:
        from worker_task import WorkerTask
        env.app_workerTask = WorkerTask()
    except Exception as e:
        logger.error('Error in importing/loading app\\'s worker tasks: {} {}'.format(e.__class__.__name__, e))
        logger.debug(pal.get_traceback(e))
        from api import report
        common.run_controlled(2,report,what='worker', status='KO', message='{} {} ({})'.format(e.__class__.__name__, e, pal.get_traceback(e)))

    try:
        from management_task import ManagementTask
        env.app_managementTask = ManagementTask()
    except Exception as e:
        logger.error('Error in importing/loading  app\\'s management tasks: {} {}'.format(e.__class__.__name__, e))
        logger.debug(pal.get_traceback(e))
        from api import report
        common.run_controlled(2,report,what='management', status='KO', message='{} {} ({})'.format(e.__class__.__name__, e, pal.get_traceback(e)))

    # Setup intervals
    worker_interval = int(env.settings['worker_interval']) if 'worker_interval' in env.settings else 300
    management_interval = int(env.settings['management_interval']) if 'management_interval' in env.settings else 60

    # Start main loop
    loop_count = 0
    while True:
        
        if loop_count % management_interval == 0:
            logger.info('Calling management (loop={})'.format(loop_count))
            if hal.HW_SUPPORTS_LED:
                hal.LED.on(); sleep(0.05); hal.LED.off()
            from management import system_management_task
            system_management_task(chronos)
            del system_management_task
            gc.collect()
            logger.info('Done management')

        if loop_count % worker_interval == 0:
            logger.info('Calling worker (loop={})'.format(loop_count))
            from worker import system_worker_task
            system_worker_task(chronos)
            del system_worker_task
            gc.collect()
            logger.info('Done worker')
            
        loop_count+=1
        sleep(1)


if __name__ == "__main__":
    start()

''')

    print('[INFO] Initializing',path+'/logger.py')
    with open(path+'/logger.py','w') as f:
        f.write('''
DEBUG = 10
INFO = 20
WARNING =  30
ERROR = 40
CRITICAL= 50

level = INFO

def emit(level,msg, det):
        print('{}: '.format(level), end='')
        print(msg, end='')
        print(' ', end='')
        print(det, end='')
        print('')

def debug(msg,det=''):
    if level <= DEBUG:
        emit('DEBUG',msg,det)

def info(msg,det=''):
    if level <= INFO:
        emit('INFO',msg,det)

def warning(msg,det=''):
    if level <= WARNING:
        emit('WARNING',msg,det)

def error(msg,det=''):
    if level <= ERROR:
        emit('ERROR',msg,det) 

def critical(msg,det=''):
    if level <= CRITICAL:
        emit('CRITICAL',msg,det)
''')
        f.write('''''')

    print('[INFO] Initializing',path+'/management.py')
    with open(path+'/management.py','w') as f:
        f.write('''import env
import logger
from api import apost, report
import gc
from common import run_controlled
import hal
import pal

def system_management_task(chronos):
    
    updates=False
    
    # Call management API
    response = run_controlled(2,apost,api='/apps/management/')
    if response and 'content' in response: 
        content = response['content']
    else:
        logger.error('Error in receiving/parsing settings, skipping the rest of the management task!')
        return
    del response
    gc.collect()

    # Update settings, Pythings and App.
    try:
        if 'settings' in content and content['settings'] != env.settings:
            updates='Settings'
            from updates_settings import update_settings
            update_settings(content)

        elif not env.frozen and env.settings['pythings_version'].upper() != 'FACTORY' and env.settings['pythings_version'] != env.pythings_version:
            updates='Pythings' 
            logger.debug('Downloading new Pythings (running version = "{}"; required version = "{}")'.format(env.pythings_version, env.settings['pythings_version']))
            from updates_pythings import update_pythings
            update_pythings(env.settings['pythings_version'])

        else:
            if env.settings['app_version'] != env.app_version:
                updates='App' 
                logger.debug('Downloading new App (running version = "{}"; required version = "{}")'.format(env.app_version, env.settings['app_version']))
                from updates_app import update_app
                update_app(env.settings['app_version'])

    except Exception as e:
        logger.error('Error in management task while updating {} ({}: {}), skipping the rest...'.format(updates, e.__class__.__name__, e))
        logger.debug(pal.get_traceback(e))
        run_controlled(2,report,what='management', status='KO', message='{} {} ({})'.format(e.__class__.__name__, e, pal.get_traceback(e)))
        return False

    gc.collect()

    # If updates, reboot.
    if updates:
        logger.info('Rebooting due to update')
        run_controlled(2,report,what='pythings', status='OK', message='Resetting due to {} update'.format(updates))
        hal.reboot()

    # Management Command (cmd), Command ID (cid) and Management Reply
    msg = content['msg'] if 'msg' in content else None
    mid = content['mid'] if 'mid' in content else None
    mty = content['type'] if 'type' in content else 'APP'
    rep = None

    # Execute system management message if we have one
    if mid and mty == 'CMD':
        cmd = msg
        try:
            logger.debug('Executing "{}"'.format(cmd))
            try:
                rep = pal.execute(cmd)
            except AttributeError:
                rep = 'Remote commands are not supported on this platform.'

        except Exception as e:
            logger.error('Error in executing app\\'s management task: {} {}'.format(e.__class__.__name__, e))
            logger.debug(pal.get_traceback(e''')
        f.write('''))
            run_controlled(2,report,what='management', status='KO', message='{} {} ({})'.format(e.__class__.__name__, e, pal.get_traceback(e)))

    # Call App's management
    if env.app_managementTask:
        try:
            logger.debug('Mem free:', pal.get_mem_free())
            if mid and mty == 'APP':
                rep=env.app_managementTask.call(msg)
            else:
                env.app_managementTask.call(None)
                
        except Exception as e:
            logger.error('Error in executing app\\'s management task: {} {}'.format(e.__class__.__name__, e))
            logger.debug(pal.get_traceback(e))
            run_controlled(2,report,what='management', status='KO', message='{} {} ({})'.format(e.__class__.__name__, e, pal.get_traceback(e)))

    # Report if everything OK..
    if mid:
        run_controlled(2,report,what='management', status='OK', message={'mid':mid,'rep':rep})
    else:
        run_controlled(2,report,what='management', status='OK')

''')

    print('[INFO] Initializing',path+'/pal.py')
    with open(path+'/pal.py','w') as f:
        f.write('''import uio
import time
import machine
import network
import logger
import env
import socket

# The following can be overwritten or extended in the Hardware Abstraction Layer

class LED(object):
    @staticmethod
    def on():
        raise NotImplementedError()     
    @staticmethod
    def off():
        raise NotImplementedError() 

class WLAN(object):  
    @staticmethod
    def sta_active(mode):
        sta = network.WLAN(network.STA_IF)
        sta.active(mode)
        if mode is True:
            from utils import connect_wifi, get_wifi_data
            essid,password = get_wifi_data()
            if essid:
                connect_wifi(sta, essid, password)
    @staticmethod
    def ap_active(mode):
        network.WLAN(network.AP_IF).active(mode)
    
class Chronos(object):
    def __init__(self, epoch_s_now=0):
        self.epoch_baseline_s    = epoch_s_now
        self.internal_baseline_s = int(time.ticks_ms()/1000)
    def epoch(self):
        if self.epoch_baseline_s is not None and self.internal_baseline_s is not None:
            current_epoch_s = (int(time.ticks_ms()/1000) - self.internal_baseline_s) + self.epoch_baseline_s        
            return current_epoch_s
        else:
            return time.ticks_ms()/1000
    
def get_tid():
    wlan = network.WLAN(network.STA_IF)
    mac_b = wlan.config('mac')
    mac_s = ':'.join( [ "%02X" % x for x in mac_b ] )
    return mac_s.replace(':','')

def get_reset_cause():
    return machine.reset_cause()

def reboot():
    machine.reset()
    time.sleep(3)

def is_frozen():
    import os
    try:
        os.stat(env.root+'/updates_pythings.py')
        return False
    except:
        return True


# The following are just platform-dependent, not hardware, and cannot be overwritten or extended.

def init():
    if logger.level > logger.DEBUG:
        logger.info('Disabling ESP debug')
        import esp
        esp.osdebug(None)
    else:
        logger.info('Leaving ESP debug enabled')

def get_payload_encrypter():  
    try:
        from crypto_aes import Aes128ecb
        return Aes128ecb      
    except:
        return None

def get_mem_free():
    import gc
    return gc.mem_free()

def get_traceback(e):
    import sys
    s = uio.StringIO()
    sys.print_exception(e, s)
    return s.getvalue() 

def get_re():
    import ure
    return ure

def socket_read(s, n):
    try: return s.read(n)
    except AttributeError: return s.recv(n)

def socket_readline(s):
    return s.readline()

def socket_write(s,data):
    s.write(data)

def socket_ssl(s):
    import ussl
    return ussl.wrap_socket(s)

def execute(cmd):
    import uos
    mystdout = uio.StringIO()
    err = ''
    uos.dupterm(mystdout)
    try:
        exec(cmd)
    except Exception as e:
        err = get_traceback(e)
    uos.dupterm(None)
    return (mystdout.getvalue() + err)

MODEM_PWKEY_PIN    = None
MODEM_RST_PIN      = None
MODEM_POWER_ON_PIN = None
MODEM_TX_PIN       = 5
MODEM_RX_PIN       = 4
''')
        f.write('''''')

    print('[INFO] Initializing',path+'/platform.py')
    with open(path+'/platform.py','w') as f:
        f.write('''platform = 'esp8266_sim800'
''')
        f.write('''''')

    print('[INFO] Initializing',path+'/preregister.py')
    with open(path+'/preregister.py','w') as f:
        f.write('''import logger
import env
from common import run_controlled
from api import apost

def preregister():
    from crypto_rsa import Srsa
    pubkey = 28413003199647341169755148817272580434684756919496624803561225904937920874272008267922241718272669080997784342773848675977238304083346116914731539644572572184061626687258523348629880944116435872100013777281682624539900472318355160325153486782544158202452609602511838141993451856549399731403548343252478723563
    logger.info('Pre-registering myself with aes128ecb key="{}"'.format(env.payload_encrypter.key))
    response = run_controlled(None,
                              apost,
                              api='/things/preregister/',
                              data={'key': Srsa(pubkey).encrypt_text(str(env.payload_encrypter.key)),
                                    'kty': 'aes128ecb',
                                    'ken': 'srsa1'})        
    if not response:
        raise Exception('Empty Response from preregister')
    
    return response['content']['token']
''')
        f.write('''''')

    print('[INFO] Initializing',path+'/register.py')
    with open(path+'/register.py','w') as f:
        f.write('''import logger
import env
from common import run_controlled
from api import apost
from platform import platform

def register():
    logger.info('Registering myself with tid={} and aid={}'.format(env.tid,env.aid))
    response = run_controlled(None,
                                     apost,
                                     api='/things/register/',
                                     data={'tid': env.tid,
                                           'aid': env.aid,
                                           'app_version': env.app_version,
                                           'pythings_version': env.pythings_version,
                                           'pool': env.pool,
                                           'frozen':env.frozen,
                                           'platform':platform})
    if not response:
        raise Exception('Empty Response from register')
    
    return (response['content']['token'], response['content']['epoch'])
''')
        f.write('''''')

    print('[INFO] Initializing',path+'/SIM800L.py')
    with open(path+'/SIM800L.py','w') as f:
        f.write('''
# Imports
import time
import json

# Setup logging.
try:
    import logging
    logger = logging.getLogger(__name__)
except:
    try:
        import logger
    except:
        class Logger(object):
            level = 'INFO'
            @classmethod
            def debug(cls, text):
                if cls.level == 'DEBUG': print('DEBUG:', text)
            @classmethod
            def info(cls, text):
                print('INFO:', text)
            @classmethod
            def warning(cls, text):
                print('WARN:', text)
        logger = Logger()


class GenericATError(Exception):
    pass


class Response(object):

    def __init__(self, status_code, content):
        self.status_code = int(status_code)
        self.content     = content


class Modem(object):

    def __init__(self, uart=None, MODEM_PWKEY_PIN=None, MODEM_RST_PIN=None, MODEM_POWER_ON_PIN=None, MODEM_TX_PIN=None, MODEM_RX_PIN=None):

        # Pins
        self.MODEM_PWKEY_PIN    = MODEM_PWKEY_PIN
        self.MODEM_RST_PIN      = MODEM_RST_PIN
        self.MODEM_POWER_ON_PIN = MODEM_POWER_ON_PIN
        self.MODEM_TX_PIN       = MODEM_TX_PIN
        self.MODEM_RX_PIN       = MODEM_RX_PIN

        # Uart
        self.uart = uart

        self.initialized = False
        self.modem_info = None


    #----------------------
    #  Modem initializer
    #----------------------

    def initialize(self):

        logger.debug('Initializing modem...')

        if not self.uart:
            from machine import UART, Pin

            # Pin initialization
            MODEM_PWKEY_PIN_OBJ = Pin(self.MODEM_PWKEY_PIN, Pin.OUT) if self.MODEM_PWKEY_PIN else None
            MODEM_RST_PIN_OBJ = Pin(self.MODEM_RST_PIN, Pin.OUT) if self.MODEM_RST_PIN else None
            MODEM_POWER_ON_PIN_OBJ = Pin(self.MODEM_POWER_ON_PIN, Pin.OUT) if self.MODEM_POWER_ON_PIN else None
            #MODEM_TX_PIN_OBJ = Pin(self.MODEM_TX_PIN, Pin.OUT) # Not needed as we use MODEM_TX_PIN
            #MODEM_RX_PIN_OBJ = Pin(self.MODEM_RX_PIN, Pin.IN)  # Not needed as we use MODEM_RX_PIN

            # Status setup
            if MODEM_PWKEY_PIN_OBJ:
                MODEM_PWKEY_PIN_OBJ.value(0)
            if MODEM_RST_PIN_OBJ:
                MODEM_RST_PIN_OBJ.value(1)
            if MODEM_POWER_ON_PIN_OBJ:
                MODEM_POWER_ON_PIN_OBJ.value(1)

            # Setup UART
            self.uart = UART(1, 9600, timeout=1000, rx=self.MODEM_TX_PIN, tx=self.MODEM_RX_PIN)

        # Test AT commands
        retries = 0
        while True:
            try:
                self.modem_info = self.execute_at_command('modeminfo')
            except:
                retries+=1
                if retries < 3:
                    logger.debug('Error in getting modem info, retrying.. (#{})'.format(retries))
                    time.sleep(3)
                else:
                    raise
            else:
                break

        logger.debug('Ok, modem "{}" is ready and accepting commands'.format(self.m''')
        f.write('''odem_info))

        # Set initialized flag and support vars
        self.initialized = True


    #----------------------
    # Execute AT commands
    #----------------------
    def execute_at_command(self, command, data=None, clean_output=True):

        # Commands dictionary. Not the best approach ever, but works nicely.
        commands = {
                    'modeminfo':  {'string':'ATI', 'timeout':3, 'end': 'OK'},
                    'fwrevision': {'string':'AT+CGMR', 'timeout':3, 'end': 'OK'},
                    'battery':    {'string':'AT+CBC', 'timeout':3, 'end': 'OK'},
                    'scan':       {'string':'AT+COPS=?', 'timeout':60, 'end': 'OK'},
                    'network':    {'string':'AT+COPS?', 'timeout':3, 'end': 'OK'},
                    'signal':     {'string':'AT+CSQ', 'timeout':3, 'end': 'OK'},
                    'checkreg':   {'string':'AT+CREG?', 'timeout':3, 'end': None},
                    'setapn':     {'string':'AT+SAPBR=3,1,"APN","{}"'.format(data), 'timeout':3, 'end': 'OK'},
                    'initgprs':   {'string':'AT+SAPBR=3,1,"Contype","GPRS"', 'timeout':3, 'end': 'OK'}, # Appeared on hologram net here or below
                    'opengprs':   {'string':'AT+SAPBR=1,1', 'timeout':3, 'end': 'OK'},
                    'getbear':    {'string':'AT+SAPBR=2,1', 'timeout':3, 'end': 'OK'},
                    'inithttp':   {'string':'AT+HTTPINIT', 'timeout':3, 'end': 'OK'},
                    'sethttp':    {'string':'AT+HTTPPARA="CID",1', 'timeout':3, 'end': 'OK'},
                    'enablessl':  {'string':'AT+HTTPSSL=1', 'timeout':3, 'end': 'OK'},
                    'disablessl': {'string':'AT+HTTPSSL=0', 'timeout':3, 'end': 'OK'},
                    'initurl':    {'string':'AT+HTTPPARA="URL","{}"'.format(data), 'timeout':3, 'end': 'OK'},
                    'doget':      {'string':'AT+HTTPACTION=0', 'timeout':3, 'end': '+HTTPACTION'},
                    'setcontent': {'string':'AT+HTTPPARA="CONTENT","{}"'.format(data), 'timeout':3, 'end': 'OK'},
                    'postlen':    {'string':'AT+HTTPDATA={},5000'.format(data), 'timeout':3, 'end': 'DOWNLOAD'},  # "data" is data_lenght in this context, while 5000 is the timeout
                    'dumpdata':   {'string':data, 'timeout':1, 'end': 'OK'},
                    'dopost':     {'string':'AT+HTTPACTION=1', 'timeout':3, 'end': '+HTTPACTION'},
                    'getdata':    {'string':'AT+HTTPREAD', 'timeout':3, 'end': 'OK'},
                    'closehttp':  {'string':'AT+HTTPTERM', 'timeout':3, 'end': 'OK'},
                    'closebear':  {'string':'AT+SAPBR=0,1', 'timeout':3, 'end': 'OK'}
        }

        # References:
        # https://github.com/olablt/micropython-sim800/blob/4d181f0c5d678143801d191fdd8a60996211ef03/app_sim.py
        # https://arduino.stackexchange.com/questions/23878/what-is-the-proper-way-to-send-data-through-http-using-sim908
        # https://stackoverflow.com/questions/35781962/post-api-rest-with-at-commands-sim800
        # https://arduino.stackexchange.com/questions/34901/http-post-request-in-json-format-using-sim900-module (full post example)

        # Sanity checks
        if command not in commands:
            raise Exception('Unknown command "{}"'.format(command))

        # Support vars
        command_string  = commands[command]['string']
        excpected_end   = commands[command]['end']
        timeout         = commands[command]['timeout']
        processed_lines = 0

        # Execute the AT command
        command_string_for_at = "{}\\r\\n".format(command_string)
        logger.debug('Writing AT command "{}"'.format(command_string_for_at.encode('utf-8')))
        self.uart.write(command_string_for_at)

        # Support vars
        pre_end = True
        output  = ''
        empty_reads = 0

        while True:

            line = self.uart.readline()
            if not line:
                time.sleep(1)
                empty_reads += 1
                if empty_reads > timeout:
                    raise Exception('Timeout for command "{}" (timeout={})'.format(command, timeout))
                    #logger.warning('Timeout for command "{}" (timeout={})'.format(command, timeout))
                    #break
            else:
                logger.debug('Read "{}"'.format(line))

                # Convert line to string
                line_str = line.decode('utf-8')

                # Do we have an error?
                if line_str == 'ERROR\\r\\n':
                    raise GenericATError('Got generic AT error')

                # If we had a pre-end, do we have the expected end?
                if line_str == '{}\\r\\n'.format(excpected_end):
                    logger.debug('Detected exact end')
                    break
                if pre_end and line_str.startswith('{}'.format(excpected_end)):
                    logger.debug('Detected startwith end (and adding this line to the output too)')
                    output += line_str
                    break

                # Do we have a pre-end?
                if line_str == '\\r\\n':
                    pre_end = True
                    logger.debug('Detected pre-end')
                else:
                    pre_end = False

                # Keep track of processed lines and stop if exceeded
                processed_lines+=1

                # Save this line unless in particular conditions
                if command == 'getdata' and line_str.startswith('+HTTPREAD:'):
                    pass
                else:
                    output += line_str

        # Remove the command string from the output
        output = output.replace(command_string+'\\r\\r\\n', '')

        # ..and remove the last \\r\\n added by the AT protocol
        if output.endswith('\\r\\n'):
            output = output[:-2]

        # Also, clean output if needed
        if clean_output:
            output = output.replace('\\r', '')
            output = output.replace('\\n\\n', '')
            if output.startswith('\\n'):
                output = output[1:]
            if output.endswith('\\n'):
                output = output[:-1]

        logger.debug('Returning "{}"'.format(output.encode('utf8')))

        # Return
        return output


    #----------------------
    #  Function commands
    #----------------------

    def get_info(self):
        output = self.execute_at_command('modeminfo')
        return output

    def battery_status(self):
        output = self.execute_at_command('battery')
        return output

    def scan_networks(self):
        networks = []
        output = self.execute_at_command('scan')
        pieces = output.split('(', 1)[1].split(')')
        for piece in pieces:
            piece = piece.replace(',(','')
            subpieces = piece.split(',')
            if len(subpieces) != 4:
                continue
            networks.append({'name': json.loads(subpieces[1]), 'shortname': json.loads(subpieces[2]), 'id': json.loads(subpieces[3])})
        return networks

    def get_current_network(self):
        output = self.execute_at_command('network')
        network = output.split(',')[-1]
        if network.startswith('"'):
            network = network[1:]
        if network.endswith('"'):
            network = network[:-1]
        # If after filtering we did not filter anything: there was no network
        if network.startswith('+COPS'):
            return None
        return network

    def get_signal_strength(self):
        # See more at https://m2msupport.net/m2msupport/atcsq-signal-quality/
        output = self.execute_at_command('signal')
        signal = int(output.split(':')[1].split(',')[0])
        signal_ratio = float(signal)/float(30) # 30 is the maximum value (2 is the minimum)
        return signal_ratio

    def get_ip_addr(self):
        output = self.execute_at_command('getbear')
        output = output.split('+')[-1] # Remove potential leftovers in the buffer before the "+SAPBR:" response
        pieces = output.split(',')
        if len(pieces) != 3:
            raise Exception('Cannot parse "{}" to get an IP address'.format(output))
        ip_addr = pieces[2].replace('"','')
        if len(ip_addr.split('.')) != 4:
            raise Exception('Cannot parse "{}" to get an IP address'.format(output))
        if ip_addr == '0.0.0.0':
            return None
        return ip_addr

    def connect(self, apn):
        if not self.initialized:
            raise Exception('Modem is not initialized, cannot connect')

        # Are we already connected?
        if self.get_ip_addr():
            logger.debug('Modem is already connected, not reconnecting.')
            return

        # Closing bearer if left opened from a previous connect gone wrong:
        logger.debug('Trying to close the bearer in case it was left open somehow..')
        try:
            self.execute_at_command('closebear')
        except GenericATError:
            pass

        # First, init gprs
        logger.debug('Connect step #1 (initgprs)')
        self.execute_at_command('initgprs')

        # Second, set the APN
        logger.debug('Connect step #2 (setapn)')
        self.execute_at_command('setapn', apn)

        # Then, open the GPRS connection.
        logger.debug('Connect step #3 (opengprs)')
        self.execute_at_command('opengprs')

        # Ok, now wait until we get a valid IP address
        retries = 0
        max_retries = 5
        while True:
            retries += 1
            ip_addr = self.get_ip_addr()
            if not ip_addr:
                retries += 1
                if retries > max_retries:
                    raise Exception('Cannot connect modem as could not get a valid IP address')
                logger.debug('No valid IP address yet, retrying... (#')
                time.sleep(1)
            else:
                break

    def disconnect(self):

        # Close bearer
        try:
            self.execute_at_command('closebear')
        except GenericATError:
            pass

        # Check that we are actually disconnected
        ip_addr = self.get_ip_addr()
        if ip_addr:
            raise Exception('Error, we should be disconnected but we still have an IP address ({})'.format(ip_addr))


    def http_request(self, url, mode='GET', data=None, content_type='application/json'):

        # Protocol check.
        assert url.startswith('http'), 'Unable to handle communication protocol for URL "{}"'.format(url)

        # Are we  connected?
        if not self.get_ip_addr():
            raise Exception('Error, modem is not connected')

        # Close the http context if left open somehow
        logger.debug('Close the http context if left open somehow...')
        try:
            self.execute_at_command('closehttp')
        except GenericATError:
            pass

        # First, init and set http
        logger.debug('Http request step #1.1 (inithttp)')
        self.execute_at_command('inithttp')
        logger.debug('Http request step #1.2 (sethttp)')
        self.execute_at_command('sethttp')

        # Do we have to enable ssl as well?
        ssl_available = self.modem_info >= 'SIM800 R14.00'
        if ssl_available:
            if url.startswith('https://'):
                logger.debug('Http request step #1.3 (enablessl)')
                self.execute_at_command('enablessl')
            elif url.startswith('http://'):
                logger.debug('Http request step #1.3 (disablessl)')
                self.execute_at_command('disablessl')
        else:
            if url.startswith('https://'):
                raise NotImplementedError("SSL is only supported by firmware revisions >= R14.00")

        # Second, init and execute the request
        logger.debug('Http request step #2.1 (initurl)')
        self.execute_at_command('initurl', data=url)

        if mode == 'GET':

            logger.debug('Http request step #2.2 (doget)')
            output = self.execute_at_command('doget')
            response_status_code = output.split(',')[1]
            logger.debug('Response status code: "{}"'.format(response_status_code))

        elif mode == 'POST':

            logger.debug('Http request step #2.2 (setcontent)')
            self.execute_at_command('setcontent', content_type)

            logger.debug('Http request step #2.3 (postlen)')
            self.execute_at_command('postlen', len(data))

            logger.debug('Http request step #2.4 (dumpdata)')
            self.execute_at_command('dumpdata', data)

            logger.debug('Http request step #2.5 (dopost)')
            output = self.execute_at_command('dopost')
            response_status_code = output.split(',')[1]
            logger.debug('Response status code: "{}"'.format(response_status_code))


        else:
            raise Exception('Unknown mode "{}'.format(mode))

        # Third, get data
        logger.debug('Http request step #4 (getdata)')
        response_content = self.execute_at_command('getdata', clean_output=False)

        logger.debug(response_content)

        # Then, close the http context
        logger.debug('Http request step #4 (closehttp)')
        self.execute_at_command('closehttp')

        return Response(status_code=response_status_code, content=response_content)
''')

    print('[INFO] Initializing',path+'/updates_app.py')
    with open(path+'/updates_app.py','w') as f:
        f.write('''import env
import logger
from utils import mv
from api import apost,download
from platform import platform

def update_app(version):
    files = apost(api='/apps/get/', data={'version':version, 'list':True})['content']
    # First of all remove /app.py to say that there is no valid App yet (download is in progress)
    import os
    try: os.remove(env.root+'/app.py')
    except: pass
    for file_name in files:
        if file_name in ['worker_task.py','management_task.py']:
            download(file_name=file_name, version=version, dest='{}/{}'.format(env.root, file_name),what='apps',platform=platform) 
        else:
            logger.info('NOT downloading "{}" as in forbidden list'.format(file_name))
    with open(env.root+'/app.py','w') as f:
        f.write('\\nversion=\\'{}\\''.format(version))
    logger.info('Got new, updated app')
''')
        f.write('''''')

    print('[INFO] Initializing',path+'/updates_pythings.py')
    with open(path+'/updates_pythings.py','w') as f:
        f.write('''
import env
import logger
import os
from platform import platform
from api import apost, download

def update_pythings(version):
    
    files = apost(api='/pythings/get/', data={'version':version, 'list':True, 'platform':platform})['content']

    path = env.root+'/'+version
    try:
        os.mkdir(path)
    except OSError as e:
        pass

    for file_name in files:
        if file_name != 'version.py':
            download(file_name=file_name, version=version, platform=platform, dest='{}/{}'.format(path, file_name), what='pythings')
    for file_name in files:
        if file_name == 'version.py':
            download(file_name=file_name, version=version, platform=platform, dest='{}/{}'.format(path, file_name), what='pythings')
''')
        f.write('''''')

    print('[INFO] Initializing',path+'/updates_settings.py')
    with open(path+'/updates_settings.py','w') as f:
        f.write('''
import env
import logger

def update_settings(content):
    logger.debug('Storing received settings ({} <--> {})'.format(content['settings'], env.settings))
    f = open(env.root+'/settings.json', 'w')
    import json
    f.write(json.dumps(content['settings']))
    f.close()
    logger.info('Got new, updated settings')


''')
        f.write('''''')

    print('[INFO] Initializing',path+'/utils.py')
    with open(path+'/utils.py','w') as f:
        f.write('''import os
from pal import get_re
import env
import logger

def connect_wifi(wlan, essid, password):
    wlan.connect(essid, password)

def unquote(s):
    res = s.split('%')
    for i in range(1, len(res)):
        item = res[i]
        try:
            res[i] = chr(int(item[:2], 16)) + item[2:]
        except ValueError:
            res[i] = '%' + item
    return "".join(res)

def load_param(param, default=None):
    try:
        with open(env.root+'/{}'.format(param),'r') as f:
            param = f.readline().strip()
        return param
    except Exception as e:
        return default

def load_settings():
    import json
    settings = {}
    try:
        with open(env.root+'/settings.json','r') as f:
            try:
                settings = json.loads(f.read())
            except Exception as e:
                logger.error('Cannot load json content: {}'.format(e))
    except Exception as e:
        logger.error('Cannot open settings.py: {}'.format(e))
    return settings

def mv(source,dest):
    try:
        try:
            os.remove(env.root+'/'+dest)
        except:
            pass
        os.rename(env.root+'/'+source, env.root+'/'+dest)
    except:
        pass

def get_wifi_data():
    try:
        with open(env.root+'/wifi','r') as f:
            essid = f.readline().strip()
            password = f.readline().strip()
    except:
        essid=None
        password=None
    return (essid,password)

def parseURL(url):
    parameters = {}
    path = get_re().search("(.*?)(\\?|$)", url).group(1)
    if '?' in url:
        try:
            for keyvalue in url.split('?')[1].split('&'):
                parameters[unquote(keyvalue.split('=')[0])] = unquote(keyvalue.split('=')[1])
        except IndexError:
            pass
    return path, parameters
''')
        f.write('''''')

    print('[INFO] Initializing',path+'/version.py')
    with open(path+'/version.py','w') as f:
        f.write('''version='v1.1.0'
''')
        f.write('''''')

    print('[INFO] Initializing',path+'/websetup.py')
    with open(path+'/websetup.py','w') as f:
        f.write('''
import network
import socket
import time
import logger
import json
import ure
from utils import *
import hal
from platform import platform
from version import version
import gc

def websetup(timeout_s=60, lock_session=False):
    logger.info('Starting WebSetup')
    addr = socket.getaddrinfo('0.0.0.0', 80)[0][-1]
    s = socket.socket()
    s.bind(addr)
    s.listen(0)
    s.settimeout(timeout_s)
    logger.debug('Listening on ', addr)
    
    # Start AP mode and disable client mode
    sta = network.WLAN(network.STA_IF)
    sta.active(False)
    ap = network.WLAN(network.AP_IF)
    ap.active(True)
    ap.config(essid="Thing_{}".format(hal.get_tid()), authmode=network.AUTH_WPA_WPA2_PSK, password="NewThing")

    logger.info('Done, waiting for a connection... ({}s)'.format(timeout_s))

    while True:
        try:
            gc.collect()
            
            # Handle client connection
            cl, addr = s.accept()
            logger.info('Incoming client connection from', addr[0])
            s.settimeout(None)

            # Read request
            request = str(cl.recv(1024))

            # Parse GET request
            get_request_data = ure.search("GET (.*?) HTTP\\/1\\.1", request)
            if get_request_data:
                path, parameters = parseURL(get_request_data.group(1))
                #logger.debug('Got request for path = "{}" with params = "{}"'.format(path, parameters))
            else:
                path = []
                parameters = []

            cl.write('HTTP/1.0 200 OK\\r\\n')
            cl.write('Access-Control-Allow-Methods: POST, GET, OPTIONS\\r\\n');
            cl.write("Access-Control-Allow-Origin: *\\r\\n");
            cl.write("Access-Control-Allow-Credentials: true\\r\\n");
            cl.write("Access-Control-Allow-Headers: X-CSRFToken, ACCEPT, CONTENT-TYPE, X-CSRF-TOKEN, Content-Type, Authorization, X-Requested-With\\r\\n");

            if not get_request_data: # an OPTIONS, basically
                cl.write('Content-Length: 0\\r\\n\\r\\n')
                cl.close()
                continue
            def set_api():
                cl.write('Content-Type: application/json\\r\\n')
                cl.write('\\r\\n')
            def set_page():
                cl.write('Content-Type: text/html\\r\\n')
                cl.write('\\r\\n')

            # Close connection if requesting favicon
            if 'favicon' in path:
                set_api()
                cl.close()
            
            # This is an API call
            elif 'cmd' in parameters:
                logger.info('Called API with cmd={}'.format(parameters['cmd']))
                set_api()
                cmd = parameters['cmd']
                essid = None
                if 'essid' in parameters: essid = parameters['essid']   
                password = None
                if 'password' in parameters: password = parameters['password']                    

                # Set app command
                if cmd=='set_app':
             ''')
        f.write('''       aid = None
                    aid = parameters['aid']
                    if aid is None:
                        cl.write(json.dumps({'status':'ERROR'}))
                    else:
                        with open('/aid','w') as f:
                            f.write(aid)
                    cl.write(json.dumps({'status':'OK', 'aid': load_param('aid',None)}))

                # Set apn command
                if cmd=='set_apn':
                    apn = None
                    apn = parameters['apn']
                    if apn is None:
                        cl.write(json.dumps({'status':'ERROR'}))
                    else:
                        with open('/apn','w') as f:
                            f.write(apn)
                    cl.write(json.dumps({'status':'OK', 'apn': load_param('apn',None)}))

                # Check command
                if cmd=='check':
                    import os
                    essid = get_wifi_data()[0]
                    cl.write(json.dumps({'status':'OK', 'tid': hal.get_tid(), 'platform': platform, 'version': version, 'aid':load_param('aid',None), 'apn': load_param('apn',None), 'essid': essid}))
                
                # Check_wifi command
                if cmd=='check_wifi':
                    sta.active(True)
                    essid='Unknown'
                    isconnected=False
                    essid,password = get_wifi_data()
                    if essid:
                        connect_wifi(sta, essid, password)
                        time.sleep(25)
                    isconnected = sta.isconnected()
                    sta.active(False) 
                    cl.write(json.dumps({'status':'OK', 'isconnected':isconnected, 'essid':essid}))
                
                # Scan command
                elif cmd == 'scan':
                    sta.active(True)
                    nets = sta.scan() 
                    sta.active(False)
                    cl.write(json.dumps(nets))
                          
                # Join command                  
                elif cmd == 'join':
                    if password is None or essid is None:
                        cl.write(json.dumps({'status': 'ERROR'}))
                    else:
                        sta.active(True)
                        connect_wifi(sta, essid, password)
                        time.sleep(25)
                        isconnected = sta.isconnected()
                        saved = False
                        if isconnected:
                            try:
                                with open('/wifi','w') as f:
                                    f.write('{}\\n{}'.format(essid,password))
                                saved=True
                            except:
                                saved=False
                        sta.active(False)
                        cl.write(json.dumps({'status':'OK', 'isconnected':isconnected, 'essid':essid, 'saved':saved}))
                
                # Close command
                elif cmd == 'close':
                    cl.write(json.dumps({'status': 'OK'}))
                    cl.close()
                    s.close()
                    break

            else:
                #logger.debug('Serving main page')
                set_page()
                cl.write('Please go to your vendor\\'s Website to configure this device.\\r\\n')

            # Close client connection at the end
            cl.close()
        
        except OSError as e:
            if str(e) == "[Errno 110] ETIMEDOUT":
                logger.info('Exiting due to no incoming connections')
                s.close()
                break
            import sys
            sys.print_exception(e)
            try: cl.close()
            except: pass
            try: s.close()
            except: pass
            time.sleep(3)
''')

    print('[INFO] Initializing',path+'/worker.py')
    with open(path+'/worker.py','w') as f:
        f.write('''import env
import logger
from api import apost, report
import gc
import pal
from common import run_controlled

def system_worker_task(chronos):
    
    # Call App's worker    
    if env.app_workerTask:
        worker_msg = None
        try:
            logger.debug('Mem free:', pal.get_mem_free())
            worker_msg = env.app_workerTask.call()
            if worker_msg:
                run_controlled(2,apost,api='/apps/worker/', data={'msg': worker_msg })
            report('worker','OK')
        except Exception as e:
            logger.error('Error in executing app\\'s worker taks or sending its data: {} {}'.format(e.__class__.__name__, e))
            logger.debug(pal.get_traceback(e))
            run_controlled(2,report,what='worker', status='KO', message='{} {} ({})'.format(e.__class__.__name__, e, pal.get_traceback(e)))
            ''')
        f.write('''''')

    with open(path+'/initialized','w') as f:
        f.write('')

install()
            
    