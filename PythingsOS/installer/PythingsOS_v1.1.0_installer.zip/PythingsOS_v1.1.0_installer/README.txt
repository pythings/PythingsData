
|================================
|  PythingsOS Installer README  |
|================================

** Always extract this archive before running the installer! **

On Windows: make sure to have Python installed, then either double click on the "installer.py" file or, if it does not work, open a Command Prompt and type "py installer.py" or "python installer.py" depending on your Python installation.

On Mac: double click on the "installer.command", or execute the "installer.sh" in a Shell.

On Linux: execute the "installer.sh" in a Shell, as root (i.e. "sudo installer.sh").
