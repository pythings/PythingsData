import machine; machine.reset()
