ampy -p /your/serialport put /path/to/yourfile.py
