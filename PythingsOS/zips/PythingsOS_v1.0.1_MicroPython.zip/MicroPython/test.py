import uos
import myio
import uio

# For Micropython esp8266
#import os
#import myio
#os.dupterm(myio)
#myio.clear()
#exec("print('hello world')")
# now, access result of "exec" trough "myio.data"

# For Micropython Unix Port: 
mystdout = uio.StringIO()
uos.dupterm(mystdout, 1)
exec("print('hello world')")
uos.dupterm(None,1 )
print('JUST ONCE?')
print('======================')
print(mystdout.getvalue())
print('======================')

# now, access result of "exec" trough "myio.data"



# For Python:
# TODO: add try/except
#     from io import StringIO
#     print('======================================')
# 
#     old_stdout = sys.stdout
#     sys.stdout = mystdout = StringIO()
#     exec("print('hello world')")    
#     sys.stdout = old_stdout
#     print('--------------------------------------')    
#     print(mystdout.getvalue())
#     print('======================================')
        
